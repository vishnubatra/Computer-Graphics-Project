#ifndef DISPLAY_FUNCTIONS_H
#define DISPLAY_FUNCTIONS_H
#define GL_SILENCE_DEPRECATION

#include <unistd.h>
#include <OpenGL/gl.h>
#include <GLUT/glut.h>
#include <iostream>
using namespace std;
#include <math.h>
#define PI 3.14159265358979323846
#include <cstdio>

// Declare display functions
void display();
void display1();
void display2();
void display3();
void display_day();
void display_night();
#endif // DISPLAY_FUNCTIONS_H
