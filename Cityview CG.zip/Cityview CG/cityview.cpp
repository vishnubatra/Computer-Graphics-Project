#define GL_SILENCE_DEPRECATION

#include <unistd.h>
#include <OpenGL/gl.h>
#include <GLUT/glut.h>
#include <iostream>
using namespace std;
#include <math.h>
#define PI 3.14159265358979323846
#include <cstdio>
#include "globals.h"
#include "displayFunctions.h"

GLfloat position = 0.0f;
GLfloat speed = 0.01f;
GLfloat position1 = 0.0f;
GLfloat speed1 = 0.007f;
GLfloat position2 = 0.0f;
GLfloat speed2 = 0.019f;
GLfloat position3 = 0.0f;
GLfloat speed3 = 0.03f;
GLfloat position5 = 0.0f;
GLfloat speed5 = 0.017f;
GLfloat position4 = 0.0f;
GLfloat speed4 = 0.018f;
GLfloat position6 = 0.0f;
GLfloat speed6 = 0.03f;

GLfloat x = -.8f;
GLfloat y = .8f;
GLfloat radius = .07f;
int triangleAmount = 20; // # of triangles used to draw circle

// GLfloat radius = 0.8f; //radius
GLfloat twicePi = 2.0f * 3.14159265358979323846;

void updateobj(int value){
    if (position > 1.0)
        position = -1.0f;
    if (position1 > 1.50)
        position1 = -1.0f;
    if (position2 < -1.20)
        position2 = .99f;
    if (position3 < -1.50)
        position3 = 1.0f;
    if (position5 > 1.50)
        position5 = -1.50f;
    if (position4 > 1.50)
        position4 = -1.50f;
    if (position6 < -1.5)
        position6 = 2.0f;

    position += speed;
    position1 += speed1;
    position2 -= speed2;
    position3 -= speed3;
    position5 += speed5;
    position4 += speed4;
    position6 -= speed6;

    glutPostRedisplay();
    glutTimerFunc(100, updateobj, 0);
}

void SpecialInput(int key, int x, int y)
{
    switch (key)
    {
    case GLUT_KEY_UP:
        glutDisplayFunc(display1);
        break;
    case GLUT_KEY_DOWN:
        glutDisplayFunc(display2);
        break;
    case GLUT_KEY_LEFT:
        glutDisplayFunc(display3);
        break;
    }
    //speed = .01;
    glutPostRedisplay();
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutCreateWindow("City Veiw");
    glutInitWindowSize(800, 800);
    glutDisplayFunc(display1);
    glutTimerFunc(100, updateobj, 0);
    glutSpecialFunc(SpecialInput);
    glutMainLoop();
    return 0;
}
