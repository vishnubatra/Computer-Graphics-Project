#include "displayFunctions.h"
#include "globals.h"

void display(){
    //Grass circle overlapping
    
    int w;
    glColor3ub(51, 102, 0);
    x = 0.14f;
    y = -.5f;
    radius = .05f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (w = 0; w <= triangleAmount; w++)
    {
        glVertex2f(
            x + (radius * cos(w * twicePi / triangleAmount)),
            y + (radius * sin(w * twicePi / triangleAmount)));
    }
    glEnd();

    // road1

    glBegin(GL_QUADS);
    glColor3ub(115, 115, 115);
    glVertex2f(1.0, -0.6);
    glVertex2f(1.0, -0.53);
    glVertex2f(-1.0, -0.53);
    glVertex2f(-1.0, -0.6);
    glEnd();

    glBegin(GL_QUADS); // road line
    glColor3ub(230, 255, 255);
    glVertex2f(1.0, -0.54);
    glVertex2f(1.0, -0.5390);
    glVertex2f(-1.0, -0.5390);
    glVertex2f(-1.0, -0.54);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.50, -0.565);
    glVertex2f(-0.50, -0.557);
    glVertex2f(-1.0, -0.557);
    glVertex2f(-1.0, -0.565);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(0.20, -0.565);
    glVertex2f(0.20, -0.557);
    glVertex2f(-0.30, -0.557);
    glVertex2f(-0.30, -0.565);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(0.40, -0.565);
    glVertex2f(0.40, -0.557);
    glVertex2f(0.90, -0.557);
    glVertex2f(0.90, -0.565);
    glEnd();

    // road 2

    glBegin(GL_QUADS);
    glColor3ub(115, 115, 115);
    glVertex2f(1.0, -0.7);
    glVertex2f(1.0, -0.6195);
    glVertex2f(-1.0, -0.6195);
    glVertex2f(-1.0, -0.7);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(230, 255, 255);
    glVertex2f(1.0, -0.6295);
    glVertex2f(1.0, -0.625);
    glVertex2f(-1.0, -0.625);
    glVertex2f(-1.0, -0.6295);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(230, 255, 255);
    glVertex2f(1.0, -0.695);
    glVertex2f(1.0, -0.69);
    glVertex2f(-1.0, -0.69);
    glVertex2f(-1.0, -0.695);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-.5, -0.66);
    glVertex2f(-.50, -0.67);
    glVertex2f(-1.0, -0.67);
    glVertex2f(-1.0, -0.66);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(.2, -0.66);
    glVertex2f(.20, -0.67);
    glVertex2f(-.30, -0.67);
    glVertex2f(-.30, -0.66);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(.4, -0.66);
    glVertex2f(.40, -0.67);
    glVertex2f(.90, -0.67);
    glVertex2f(.90, -0.66);
    glEnd();

    // road 3
    glBegin(GL_QUADS);
    glColor3ub(115, 115, 115);
    glVertex2f(1.0, -0.8);
    glVertex2f(1.0, -0.7195);
    glVertex2f(-1.0, -0.7195);
    glVertex2f(-1.0, -0.8);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(230, 255, 255);
    glVertex2f(1.0, -0.7295);
    glVertex2f(1.0, -0.725);
    glVertex2f(-1.0, -0.725);
    glVertex2f(-1.0, -0.7295);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(230, 255, 255);
    glVertex2f(1.0, -0.795);
    glVertex2f(1.0, -0.79);
    glVertex2f(-1.0, -0.79);
    glVertex2f(-1.0, -0.795);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-.5, -0.76);
    glVertex2f(-.50, -0.77);
    glVertex2f(-1.0, -0.77);
    glVertex2f(-1.0, -0.76);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(.2, -0.76);
    glVertex2f(.20, -0.77);
    glVertex2f(-.30, -0.77);
    glVertex2f(-.30, -0.76);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(.4, -0.76);
    glVertex2f(.40, -0.77);
    glVertex2f(.90, -0.77);
    glVertex2f(.90, -0.76);
    glEnd();
    
    // road4
    glBegin(GL_QUADS);
    glColor3ub(115, 115, 115);
    glVertex2f(1.0, -0.86);
    glVertex2f(1.0, -0.97);
    glVertex2f(-1.0, -0.97);
    glVertex2f(-1.0, -0.86);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(1.0, -0.87);
    glVertex2f(1.0, -0.875);
    glVertex2f(-1.0, -0.875);
    glVertex2f(-1.0, -0.87);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-.5, -0.91);
    glVertex2f(-.50, -0.92);
    glVertex2f(-1.0, -0.92);
    glVertex2f(-1.0, -0.91);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(.2, -0.91);
    glVertex2f(.20, -0.92);
    glVertex2f(-.30, -0.92);
    glVertex2f(-.30, -0.91);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(.4, -0.91);
    glVertex2f(.40, -0.92);
    glVertex2f(.90, -0.92);
    glVertex2f(.90, -0.91);
    glEnd();

    // red-white pole
    glBegin(GL_QUADS);
    glColor3ub(255, 0, 0);
    glVertex2f(.43, -0.8);
    glVertex2f(.43, -0.7);
    glVertex2f(.42, -0.7);
    glVertex2f(.42, -0.8);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(.43, -0.7);
    glVertex2f(.43, -0.6);
    glVertex2f(.42, -0.6);
    glVertex2f(.42, -0.7);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 0, 0);
    glVertex2f(.43, -0.6);
    glVertex2f(.43, -0.5);
    glVertex2f(.42, -0.5);
    glVertex2f(.42, -0.6);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(.43, -0.5);
    glVertex2f(.43, -0.45);
    glVertex2f(.42, -0.45);
    glVertex2f(.42, -0.5);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(.43, -0.45);
    glVertex2f(.43, -0.4);
    glVertex2f(.42, -0.4);
    glVertex2f(.42, -0.45);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 0, 0);
    glVertex2f(.44, -0.43);
    glVertex2f(.435, -0.45);
    glVertex2f(.405, -0.45);
    glVertex2f(.41, -0.43);
    glEnd();

    // tree

    glColor3ub(51, 102, 0);
    int q;

    x = 0.19f;
    y = -.5f;
    radius = .03f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (q = 0; q <= triangleAmount; q++)
    {
        glVertex2f(
            x + (radius * cos(q * twicePi / triangleAmount)),
            y + (radius * sin(q * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(51, 102, 0);
    int r;

    x = 0.22f;
    y = -.48f;
    radius = .03f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (r = 0; r <= triangleAmount; r++)
    {
        glVertex2f(
            x + (radius * cos(r * twicePi / triangleAmount)),
            y + (radius * sin(r * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(51, 102, 0);
    int t;

    x = 0.25f;
    y = -.5f;
    radius = .03f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (t = 0; t <= triangleAmount; t++)
    {
        glVertex2f(
            x + (radius * cos(t * twicePi / triangleAmount)),
            y + (radius * sin(t * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(77, 153, 0);
    int u;

    x = 0.28f;
    y = -.49f;
    radius = .02f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (u = 0; u <= triangleAmount; u++)
    {
        glVertex2f(
            x + (radius * cos(u * twicePi / triangleAmount)),
            y + (radius * sin(u * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(77, 153, 0);
    int o;

    x = 0.31f;
    y = -.48f;
    radius = .02f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (o = 0; o <= triangleAmount; o++)
    {
        glVertex2f(
            x + (radius * cos(o * twicePi / triangleAmount)),
            y + (radius * sin(o * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(77, 153, 0);
    int p;

    x = 0.34f;
    y = -.49f;
    radius = .02f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (p = 0; p <= triangleAmount; p++)
    {
        glVertex2f(
            x + (radius * cos(p * twicePi / triangleAmount)),
            y + (radius * sin(p * twicePi / triangleAmount)));
    }
    glEnd();

    glBegin(GL_QUADS);        // side line
    glColor3ub(255, 214, 51); // yellow
    glVertex2f(0.75, -0.5);
    glVertex2f(0.75, -0.49);
    glVertex2f(0.12, -0.49);
    glVertex2f(.12, -0.50);
    glEnd();

    // grass

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 0);
    glVertex2f(1.0, -0.53);
    glVertex2f(1.0, -0.50);
    glVertex2f(-1.0, -0.50);
    glVertex2f(-1.0, -0.53);
    glEnd();
    // mati

    glBegin(GL_QUADS);
    glColor3ub(102, 51, 0);
    glVertex2f(1.0, -0.52);
    glVertex2f(1.0, -0.53);
    glVertex2f(-1.0, -0.53);
    glVertex2f(-1.0, -0.52);
    glEnd();

    // car
    glPushMatrix();
    glTranslatef(position2, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glColor3ub(230, 255, 255);
    glVertex2f(.23, -0.58);
    glVertex2f(.23, -0.55);
    glVertex2f(.32, -0.55);
    glVertex2f(.32, -0.58);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(230, 255, 255);
    glVertex2f(.26, -0.55);
    glVertex2f(.26, -0.51);
    glVertex2f(.313, -0.51);
    glVertex2f(.313, -0.55);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(.265, -0.55);
    glVertex2f(.265, -0.515);
    glVertex2f(.309, -0.515);
    glVertex2f(.309, -0.55);
    glEnd();
    /*glBegin(GL_QUADS);
         glColor3ub(255, 0, 0);
         glVertex2f(.29,-0.51);
         glVertex2f(.29,-0.502);
         glVertex2f(.3,-0.502);
         glVertex2f(.3,-0.51);
         glEnd();*/

    glColor3ub(7, 8, 7);
    int i;

    x = .25f;
    y = -.578f;
    radius = .01f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (i = 0; i <= triangleAmount; i++)
    {
        glVertex2f(
            x + (radius * cos(i * twicePi / triangleAmount)),
            y + (radius * sin(i * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(7, 8, 7);
    int j;

    x = .30f;
    y = -.578f;
    radius = .01f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (j = 0; j <= triangleAmount; j++)
    {
        glVertex2f(
            x + (radius * cos(j * twicePi / triangleAmount)),
            y + (radius * sin(j * twicePi / triangleAmount)));
    }
    glEnd();
    glPopMatrix();

    glBegin(GL_QUADS);
    glColor3ub(230, 255, 255);
    glVertex2f(1.0, -0.595);
    glVertex2f(1.0, -0.590);
    glVertex2f(-1.0, -0.590);
    glVertex2f(-1.0, -0.595);
    glEnd();

    // grass 2

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 0);
    glVertex2f(1.0, -0.61);
    glVertex2f(1.0, -0.6);
    glVertex2f(-1.0, -0.6);
    glVertex2f(-1.0, -0.61);
    glEnd();
    // mati 2

    glBegin(GL_QUADS);
    glColor3ub(102, 51, 0);
    glVertex2f(1.0, -0.6195);
    glVertex2f(1.0, -0.61);
    glVertex2f(-1.0, -0.61);
    glVertex2f(-1.0, -0.6195);
    glEnd();

    // car3
    glPushMatrix();
    glTranslatef(position5, 0.0f, 0.0f);

    glBegin(GL_QUADS);
    glColor3ub(184, 0, 230);
    glVertex2f(-.23, -0.68);
    glVertex2f(-.23, -0.65);
    glVertex2f(-.32, -0.65);
    glVertex2f(-.32, -0.68);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(184, 0, 230);
    glVertex2f(-.26, -0.65);
    glVertex2f(-.26, -0.61);
    glVertex2f(-.313, -0.61);
    glVertex2f(-.313, -0.65);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-.265, -0.65);
    glVertex2f(-.265, -0.615);
    glVertex2f(-.309, -0.615);
    glVertex2f(-.309, -0.65);
    glEnd();
    /*glBegin(GL_QUADS);
         glColor3ub(255, 0, 0);
         glVertex2f(-.29,-0.61);
         glVertex2f(-.29,-0.602);
         glVertex2f(-.3,-0.602);
         glVertex2f(-.3,-0.61);
         glEnd();*/

    glColor3ub(7, 8, 7);
    int m;

    x = -.25f;
    y = -.678f;
    radius = .01f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (m = 0; m <= triangleAmount; m++)
    {
        glVertex2f(
            x + (radius * cos(m * twicePi / triangleAmount)),
            y + (radius * sin(m * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(7, 8, 7);
    int M;

    x = -.30f;
    y = -.678f;
    radius = .01f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (M = 0; M <= triangleAmount; M++)
    {
        glVertex2f(
            x + (radius * cos(M * twicePi / triangleAmount)),
            y + (radius * sin(M * twicePi / triangleAmount)));
    }
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(position4, 0.0f, 0.0f);
    // car4
    glBegin(GL_QUADS);
    glColor3ub(255, 77, 136);
    glVertex2f(.23, -0.68);
    glVertex2f(.23, -0.65);
    glVertex2f(.32, -0.65);
    glVertex2f(.32, -0.68);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 77, 136);
    glVertex2f(.29, -0.65);
    glVertex2f(.29, -0.61);
    glVertex2f(.24, -0.61);
    glVertex2f(.24, -0.65);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(.285, -0.65);
    glVertex2f(.285, -0.615);
    glVertex2f(.245, -0.615);
    glVertex2f(.245, -0.65);
    glEnd();
    /*glBegin(GL_QUADS);
         glColor3ub(255, 0, 0);
         glVertex2f(-.29,-0.61);
         glVertex2f(-.29,-0.602);
         glVertex2f(-.3,-0.602);
         glVertex2f(-.3,-0.61);
         glEnd();*/

    glColor3ub(7, 8, 7);
    int n;

    x = .25f;
    y = -.678f;
    radius = .01f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (n = 0; n <= triangleAmount; n++)
    {
        glVertex2f(
            x + (radius * cos(n * twicePi / triangleAmount)),
            y + (radius * sin(n * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(7, 8, 7);
    int N;

    x = .30f;
    y = -.678f;
    radius = .01f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (N = 0; N <= triangleAmount; N++)
    {
        glVertex2f(
            x + (radius * cos(N * twicePi / triangleAmount)),
            y + (radius * sin(N * twicePi / triangleAmount)));
    }
    glEnd();
    glPopMatrix();

    // grass 3

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 0);
    glVertex2f(1.0, -0.71);
    glVertex2f(1.0, -0.7);
    glVertex2f(-1.0, -0.7);
    glVertex2f(-1.0, -0.71);
    glEnd();
    // mati 3

    glBegin(GL_QUADS);
    glColor3ub(102, 51, 0);
    glVertex2f(1.0, -0.7195);
    glVertex2f(1.0, -0.71);
    glVertex2f(-1.0, -0.71);
    glVertex2f(-1.0, -0.7195);
    glEnd();

    // car2
    glPushMatrix();
    glTranslatef(position3, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glColor3f(0, 0, 1);
    glVertex2f(.43, -0.78);
    glVertex2f(.43, -0.75);
    glVertex2f(.52, -0.75);
    glVertex2f(.52, -0.78);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(0, 0, 1);
    glVertex2f(.46, -0.75);
    glVertex2f(.46, -0.71);
    glVertex2f(.513, -0.71);
    glVertex2f(.513, -0.75);
    glVertex2f(.465, -0.715);
    glVertex2f(.509, -0.715);
    glVertex2f(.509, -0.75);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 0, 0);
    glVertex2f(.49, -0.71);
    glVertex2f(.49, -0.702);
    glVertex2f(.5, -0.702);
    glVertex2f(.5, -0.71);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0, 0, 0);
    glVertex2f(.465, -0.75);
    glVertex2f(.465, -0.715);
    glVertex2f(.509, -0.715);
    glVertex2f(.509, -0.75);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 0, 0);
    glVertex2f(.49, -0.71);
    glVertex2f(.49, -0.702);
    glVertex2f(.5, -0.702);
    glVertex2f(.5, -0.71);
    glEnd();

    glColor3ub(7, 8, 7);
    int a;

    x = .45f;
    y = -.778f;
    radius = .01f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (a = 0; a <= triangleAmount; a++)
    {
        glVertex2f(
            x + (radius * cos(a * twicePi / triangleAmount)),
            y + (radius * sin(a * twicePi / triangleAmount)));
    }
    glEnd();

    glColor3ub(7, 8, 7);
    int s;

    x = .50f;
    y = -.778f;
    radius = .01f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (s = 0; s <= triangleAmount; s++)
    {
        glVertex2f(
            x + (radius * cos(s * twicePi / triangleAmount)),
            y + (radius * sin(s * twicePi / triangleAmount)));
    }
    glEnd();
    glPopMatrix();

    // GRASS 4
    glBegin(GL_QUADS);
    glColor3ub(102, 153, 0);
    glVertex2f(1.0, -0.85);
    glVertex2f(1.0, -0.8);
    glVertex2f(-1.0, -0.8);
    glVertex2f(-1.0, -0.85);
    glEnd();

    // mati 4
    glBegin(GL_QUADS);
    glColor3ub(102, 51, 0);
    glVertex2f(1.0, -0.86);
    glVertex2f(1.0, -0.85);
    glVertex2f(-1.0, -0.85);
    glVertex2f(-1.0, -0.86);
    glEnd();

    // grass4
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(1.0, -0.965);
    glVertex2f(1.0, -0.96);
    glVertex2f(-1.0, -0.96);
    glVertex2f(-1.0, -0.965);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 0);
    glVertex2f(1.0, -0.97);
    glVertex2f(1.0, -1.0);
    glVertex2f(-1.0, -1.0);
    glVertex2f(-1.0, -0.97);
    glEnd();

    // LEFT SIDE BLDING 2

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 153);
    glVertex2f(-.75, -0.4);
    glVertex2f(-.75, -0.13);
    glVertex2f(-0.8, -0.13);
    glVertex2f(-.8, -0.4);
    glEnd();
    // LEFT SIDE BLDING 3

    glBegin(GL_QUADS);
    glColor3ub(117, 163, 163);
    glVertex2f(-.65, -0.4);
    glVertex2f(-.65, -0.08);
    glVertex2f(-0.75, -0.08);
    glVertex2f(-.75, -0.4);
    glEnd();

    // LEFT SIDE BLDING 4

    glBegin(GL_QUADS);
    glColor3ub(191, 191, 191);
    glVertex2f(-.6, -0.4);
    glVertex2f(-.6, 0.31);
    glVertex2f(-0.65, 0.31);
    glVertex2f(-.65, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(204, 204, 204);
    glVertex2f(-.5, -0.4);
    glVertex2f(-.5, 0.31);
    glVertex2f(-0.6, 0.31);
    glVertex2f(-.6, -0.4);
    glEnd();

    // Glass

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(-.59, -0.4);
    glVertex2f(-.59, 0.29);
    glVertex2f(-0.64, 0.29);
    glVertex2f(-.64, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(-.51, -0.4);
    glVertex2f(-.51, 0.29);
    glVertex2f(-0.59, 0.29);
    glVertex2f(-.59, -0.4);
    glEnd();

    // LEFT SIDE BLDING 5

    glBegin(GL_QUADS);
    glColor3ub(198, 140, 83);
    glVertex2f(-.45, -0.4);
    glVertex2f(-.45, 0.09);
    glVertex2f(-0.5, 0.09);
    glVertex2f(-0.5, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(204, 153, 102);
    glVertex2f(-.4, -0.4);
    glVertex2f(-.4, 0.09);
    glVertex2f(-0.45, 0.09);
    glVertex2f(-0.45, -0.4);
    glEnd();
    // Glass
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.405, -0.4);
    glVertex2f(-.405, 0.08);
    glVertex2f(-0.447, 0.08);
    glVertex2f(-0.447, -0.4);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.457, -0.4);
    glVertex2f(-.457, 0.08);
    glVertex2f(-0.495, 0.08);
    glVertex2f(-0.495, -0.4);
    glEnd();

    // Tower Building

    glBegin(GL_QUADS);
    glColor3ub(89, 89, 89);
    glVertex2f(-.35, -0.4);
    glVertex2f(-.35, 0.35);
    glVertex2f(-0.4, 0.35);
    glVertex2f(-0.4, -0.4);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(89, 89, 89);
    glVertex2f(-.36, 0.35);
    glVertex2f(-.36, 0.37);
    glVertex2f(-0.39, 0.37);
    glVertex2f(-0.39, 0.35);
    glEnd();

    glBegin(GL_QUADS); // 1st
    glColor3ub(89, 89, 89);
    glVertex2f(-.345, 0.37);
    glVertex2f(-.345, 0.45);
    glVertex2f(-0.405, 0.45);
    glVertex2f(-0.405, 0.37);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(89, 89, 89);
    glVertex2f(-.36, 0.45);
    glVertex2f(-.36, 0.47);
    glVertex2f(-0.39, 0.47);
    glVertex2f(-0.39, 0.45);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(89, 89, 89);
    glVertex2f(-.35, 0.47);
    glVertex2f(-.35, 0.48);
    glVertex2f(-0.40, 0.48);
    glVertex2f(-0.40, 0.47);
    glEnd();

    glBegin(GL_QUADS); // 2nd
    glColor3ub(89, 89, 89);
    glVertex2f(-.33, 0.48);
    glVertex2f(-.33, 0.54);
    glVertex2f(-0.42, 0.54);
    glVertex2f(-0.42, 0.48);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(89, 89, 89);
    glVertex2f(-.36, 0.54);
    glVertex2f(-.36, 0.56);
    glVertex2f(-0.39, 0.56);
    glVertex2f(-0.39, 0.54);
    glEnd();

    glBegin(GL_QUADS); // rod
    glColor3ub(89, 89, 89);
    glVertex2f(-.38, 0.56);
    glVertex2f(-.38, 0.8);
    glVertex2f(-0.385, 0.8);
    glVertex2f(-0.385, 0.56);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(89, 89, 89);
    glVertex2f(-.365, 0.56);
    glVertex2f(-.365, 0.8);
    glVertex2f(-0.37, 0.8);
    glVertex2f(-0.37, 0.56);
    glEnd();

    glBegin(GL_QUADS); // join
    glColor3ub(89, 89, 89);
    glVertex2f(-.365, 0.8);
    glVertex2f(-.365, 0.81);
    glVertex2f(-0.385, 0.81);
    glVertex2f(-0.385, 0.8);
    glEnd();


    // left blding 6

    glBegin(GL_QUADS);
    glColor3ub(204, 153, 102);
    glVertex2f(-.2, -0.4);
    glVertex2f(-.2, -0.09);
    glVertex2f(-0.3, -0.09);
    glVertex2f(-0.3, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(198, 140, 83);
    glVertex2f(-.3, -0.4);
    glVertex2f(-.3, -0.09);
    glVertex2f(-0.37, -0.09);
    glVertex2f(-0.37, -0.4);
    glEnd();
    // Glass
    glBegin(GL_QUADS);
    glColor3ub(214, 214, 194);
    glVertex2f(-.31, -0.4);
    glVertex2f(-.31, -0.10);
    glVertex2f(-0.365, -0.10);
    glVertex2f(-0.365, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.21, -0.4);
    glVertex2f(-.21, -0.10);
    glVertex2f(-0.29, -0.10);
    glVertex2f(-0.29, -0.4);
    glEnd();

    // left blding 7

    glBegin(GL_QUADS);
    glColor3ub(117, 163, 163);
    glVertex2f(-.1, -0.4);
    glVertex2f(-.1, -0.15);
    glVertex2f(-0.15, -0.15);
    glVertex2f(-0.15, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 153);
    glVertex2f(-.15, -0.4);
    glVertex2f(-.15, -0.15);
    glVertex2f(-0.2, -0.15);
    glVertex2f(-0.2, -0.4);
    glEnd();
    // Glass
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.16);
    glVertex2f(-.103, -0.17);
    glVertex2f(-0.145, -0.17);
    glVertex2f(-0.145, -0.16);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.18);
    glVertex2f(-.103, -0.19);
    glVertex2f(-0.145, -0.19);
    glVertex2f(-0.145, -0.18);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.20);
    glVertex2f(-.103, -0.21);
    glVertex2f(-0.145, -0.21);
    glVertex2f(-0.145, -0.20);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.22);
    glVertex2f(-.103, -0.23);
    glVertex2f(-0.145, -0.23);
    glVertex2f(-0.145, -0.22);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.24);
    glVertex2f(-.103, -0.25);
    glVertex2f(-0.145, -0.25);
    glVertex2f(-0.145, -0.24);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.26);
    glVertex2f(-.103, -0.27);
    glVertex2f(-0.145, -0.27);
    glVertex2f(-0.145, -0.26);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.28);
    glVertex2f(-.103, -0.29);
    glVertex2f(-0.145, -0.29);
    glVertex2f(-0.145, -0.28);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.30);
    glVertex2f(-.103, -0.31);
    glVertex2f(-0.145, -0.31);
    glVertex2f(-0.145, -0.30);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.32);
    glVertex2f(-.103, -0.33);
    glVertex2f(-0.145, -0.33);
    glVertex2f(-0.145, -0.32);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.34);
    glVertex2f(-.103, -0.35);
    glVertex2f(-0.145, -0.35);
    glVertex2f(-0.145, -0.34);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.103, -0.36);
    glVertex2f(-.103, -0.37);
    glVertex2f(-0.145, -0.37);
    glVertex2f(-0.145, -0.36);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.16);
    glVertex2f(-.155, -0.17);
    glVertex2f(-0.195, -0.17);
    glVertex2f(-0.195, -0.16);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.18);
    glVertex2f(-.155, -0.19);
    glVertex2f(-0.195, -0.19);
    glVertex2f(-0.195, -0.18);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.20);
    glVertex2f(-.155, -0.21);
    glVertex2f(-0.195, -0.21);
    glVertex2f(-0.195, -0.20);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.22);
    glVertex2f(-.155, -0.23);
    glVertex2f(-0.195, -0.23);
    glVertex2f(-0.195, -0.22);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.24);
    glVertex2f(-.155, -0.25);
    glVertex2f(-0.195, -0.25);
    glVertex2f(-0.195, -0.24);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.26);
    glVertex2f(-.155, -0.27);
    glVertex2f(-0.195, -0.27);
    glVertex2f(-0.195, -0.26);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.28);
    glVertex2f(-.155, -0.29);
    glVertex2f(-0.195, -0.29);
    glVertex2f(-0.195, -0.28);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.30);
    glVertex2f(-.155, -0.31);
    glVertex2f(-0.195, -0.31);
    glVertex2f(-0.195, -0.30);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.32);
    glVertex2f(-.155, -0.33);
    glVertex2f(-0.195, -0.33);
    glVertex2f(-0.195, -0.32);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.34);
    glVertex2f(-.155, -0.35);
    glVertex2f(-0.195, -0.35);
    glVertex2f(-0.195, -0.34);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(224, 224, 209);
    glVertex2f(-.155, -0.36);
    glVertex2f(-.155, -0.37);
    glVertex2f(-0.195, -0.37);
    glVertex2f(-0.195, -0.36);
    glEnd();

    // Tower

    glBegin(GL_QUADS);
    glColor3ub(191, 191, 191);
    glVertex2f(-.14, -0.15);
    glVertex2f(-.14, 0.05);
    glVertex2f(-0.144, 0.05);
    glVertex2f(-0.144, -0.15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(191, 191, 191);
    glVertex2f(-.16, -0.15);
    glVertex2f(-.16, 0.05);
    glVertex2f(-0.164, 0.05);
    glVertex2f(-0.164, -0.15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(191, 191, 191);
    glVertex2f(-.14, -0.0);
    glVertex2f(-.14, 0.05);
    glVertex2f(-0.164, 0.05);
    glVertex2f(-0.164, -0.0);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(191, 191, 191);
    glVertex2f(-.151, 0.05);
    glVertex2f(-.151, 0.09);
    glVertex2f(-0.153, 0.09);
    glVertex2f(-0.153, 0.05);
    glEnd();

    glBegin(GL_QUADS); // Light
    glColor3ub(255, 0, 0);
    glVertex2f(-.151, 0.09);
    glVertex2f(-.151, 0.095);
    glVertex2f(-0.153, 0.095);
    glVertex2f(-0.153, 0.09);
    glEnd();
    // left blding 8

    glBegin(GL_QUADS);
    glColor3ub(179, 179, 204);
    glVertex2f(-.05, -0.5);
    glVertex2f(-.05, -0.1);
    glVertex2f(-0.1, -0.1);
    glVertex2f(-0.1, -0.5);
    glEnd();

    //Grass-left
    glColor3ub(51, 102, 0);
    int e;

    x = 0.10f;
    y = -.45f;
    radius = .04f;
    triangleAmount = 20; // # of triangles used to draw circle

    // GLfloat radius = 0.8f; //radius
    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (e = 0; e <= triangleAmount; e++)
    {
        glVertex2f(
            x + (radius * cos(e * twicePi / triangleAmount)),
            y + (radius * sin(e * twicePi / triangleAmount)));
    }
    glEnd();
    glColor3ub(64, 128, 0);
    // actuall grass position


    // Land yellow bulding
    glBegin(GL_QUADS); // yellow
    glColor3ub(255, 209, 26);
    glVertex2f(-0.18, -0.30);
    glVertex2f(-0.18, -0.40);
    glVertex2f(-.62, -0.40);
    glVertex2f(-.62, -0.30);
    glEnd();

    // glass
    glBegin(GL_QUADS); // yellow
    glColor3ub(179, 204, 204);
    glVertex2f(-0.19, -0.32);
    glVertex2f(-0.19, -0.39);
    glVertex2f(-.61, -0.39);
    glVertex2f(-.61, -0.32);
    glEnd();

    glBegin(GL_QUADS); // yellow
    glColor3ub(255, 214, 51);
    glVertex2f(0.12, -0.50);
    glVertex2f(0.12, -0.38);
    glVertex2f(-0.20, -0.38);
    glVertex2f(-0.20, -0.50);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255); // white
    glVertex2f(0.12, -0.50);
    glVertex2f(0.12, -0.38);
    glVertex2f(0.115, -0.38);
    glVertex2f(0.115, -0.50);
    glEnd();
    glBegin(GL_QUADS); // yellow
    glColor3ub(255, 214, 51);
    glVertex2f(-0.6, -0.50);
    glVertex2f(-0.6, -0.38);
    glVertex2f(-1.0, -0.38);
    glVertex2f(-1.0, -0.50);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(115, 115, 115);
    glVertex2f(0.10, -0.50);
    glVertex2f(0.10, -0.40);
    glVertex2f(-0.98, -0.40);
    glVertex2f(-0.98, -0.50);
    glEnd();

    glBegin(GL_QUADS); // glass
    glColor3ub(221, 204, 255);
    glVertex2f(0.10, -0.50);
    glVertex2f(0.10, -0.41);
    glVertex2f(-0.98, -0.41);
    glVertex2f(-.98, -0.50);
    glEnd();

    // side black
    glBegin(GL_QUADS);
    glColor3ub(115, 115, 115);
    glVertex2f(0.10, -0.50);
    glVertex2f(0.10, -0.40);
    glVertex2f(0.08, -0.40);
    glVertex2f(.08, -0.50);
    glEnd();

    // GLASS border yellow

    glBegin(GL_QUADS);       // glass
    glColor3ub(230, 184, 0); // black yellow
    glVertex2f(0.08, -0.42);
    glVertex2f(0.08, -0.41);
    glVertex2f(-0.98, -0.41);
    glVertex2f(-.98, -0.42);
    glEnd();

    glBegin(GL_QUADS);       // glass
    glColor3ub(230, 184, 0); // black yellow y1
    glVertex2f(0.08, -0.5);
    glVertex2f(0.08, -0.42);
    glVertex2f(.076, -0.42);
    glVertex2f(.076, -0.5);
    glEnd();

    glBegin(GL_QUADS);        // glass
    glColor3ub(198, 83, 198); // violet
    glVertex2f(0.076, -0.425);
    glVertex2f(0.076, -0.42);
    glVertex2f(-0.98, -0.42);
    glVertex2f(-.98, -0.425);
    glEnd();
    glBegin(GL_QUADS);        // glass
    glColor3ub(198, 83, 198); // v1
    glVertex2f(0.076, -0.5);
    glVertex2f(0.076, -0.42);
    glVertex2f(.072, -0.42);
    glVertex2f(.072, -0.5);
    glEnd();

    glFlush();
}

void display_day(){
    // right blding 1

    glBegin(GL_QUADS);
    glColor3ub(163, 163, 194);
    glVertex2f(0.05, -0.50);
    glVertex2f(0.05, 0.15);
    glVertex2f(-0.05, 0.15);
    glVertex2f(-0.05, -0.50);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(179, 179, 204);
    glVertex2f(0.17, -0.50);
    glVertex2f(0.17, 0.15);
    glVertex2f(0.05, 0.15);
    glVertex2f(0.05, -0.50);
    glEnd();
    // glass
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, 0.12);
    glVertex2f(0.16, 0.13);
    glVertex2f(0.06, 0.13);
    glVertex2f(0.06, 0.12);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, 0.12);
    glVertex2f(0.16, 0.13);
    glVertex2f(0.06, 0.13);
    glVertex2f(0.06, 0.12);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, 0.10);
    glVertex2f(0.16, 0.11);
    glVertex2f(0.06, 0.11);
    glVertex2f(0.06, 0.10);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, 0.08);
    glVertex2f(0.16, 0.09);
    glVertex2f(0.06, 0.09);
    glVertex2f(0.06, 0.08);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, 0.06);
    glVertex2f(0.16, 0.07);
    glVertex2f(0.06, 0.07);
    glVertex2f(0.06, 0.06);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, 0.04);
    glVertex2f(0.16, 0.05);
    glVertex2f(0.06, 0.05);
    glVertex2f(0.06, 0.04);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, 0.02);
    glVertex2f(0.16, 0.03);
    glVertex2f(0.06, 0.03);
    glVertex2f(0.06, 0.02);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, 0.0);
    glVertex2f(0.16, 0.01);
    glVertex2f(0.06, 0.01);
    glVertex2f(0.06, 0.0);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.02);
    glVertex2f(0.16, -0.01);
    glVertex2f(0.06, -0.01);
    glVertex2f(0.06, -0.02);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.04);
    glVertex2f(0.16, -0.03);
    glVertex2f(0.06, -0.03);
    glVertex2f(0.06, -0.04);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.06);
    glVertex2f(0.16, -0.05);
    glVertex2f(0.06, -0.05);
    glVertex2f(0.06, -0.06);
    glEnd(); //
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.08);
    glVertex2f(0.16, -0.07);
    glVertex2f(0.06, -0.07);
    glVertex2f(0.06, -0.08);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.10);
    glVertex2f(0.16, -0.09);
    glVertex2f(0.06, -0.09);
    glVertex2f(0.06, -0.10);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.12);
    glVertex2f(0.16, -0.11);
    glVertex2f(0.06, -0.11);
    glVertex2f(0.06, -0.12);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.14);
    glVertex2f(0.16, -0.13);
    glVertex2f(0.06, -0.13);
    glVertex2f(0.06, -0.14);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.16);
    glVertex2f(0.16, -0.15);
    glVertex2f(0.06, -0.15);
    glVertex2f(0.06, -0.16);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.18);
    glVertex2f(0.16, -0.17);
    glVertex2f(0.06, -0.17);
    glVertex2f(0.06, -0.18);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.20);
    glVertex2f(0.16, -0.19);
    glVertex2f(0.06, -0.19);
    glVertex2f(0.06, -0.20);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.22);
    glVertex2f(0.16, -0.21);
    glVertex2f(0.06, -0.21);
    glVertex2f(0.06, -0.22);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.24);
    glVertex2f(0.16, -0.23);
    glVertex2f(0.06, -0.23);
    glVertex2f(0.06, -0.24);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.26);
    glVertex2f(0.16, -0.25);
    glVertex2f(0.06, -0.25);
    glVertex2f(0.06, -0.26);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.28);
    glVertex2f(0.16, -0.27);
    glVertex2f(0.06, -0.27);
    glVertex2f(0.06, -0.28);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.30);
    glVertex2f(0.16, -0.29);
    glVertex2f(0.06, -0.29);
    glVertex2f(0.06, -0.30);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.32);
    glVertex2f(0.16, -0.31);
    glVertex2f(0.06, -0.31);
    glVertex2f(0.06, -0.32);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.34);
    glVertex2f(0.16, -0.33);
    glVertex2f(0.06, -0.33);
    glVertex2f(0.06, -0.34);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.36);
    glVertex2f(0.16, -0.35);
    glVertex2f(0.06, -0.35);
    glVertex2f(0.06, -0.36);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.06);
    glVertex2f(0.16, -0.05);
    glVertex2f(0.06, -0.05);
    glVertex2f(0.06, -0.06);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(193, 215, 215);
    glVertex2f(0.16, -0.06);
    glVertex2f(0.16, -0.05);
    glVertex2f(0.06, -0.05);
    glVertex2f(0.06, -0.06);
    glEnd();

    // Right blding 2

    glBegin(GL_QUADS);
    glColor3ub(117, 163, 163);
    glVertex2f(0.25, -0.50);
    glVertex2f(0.25, 0.05);
    glVertex2f(0.17, 0.05);
    glVertex2f(0.17, -0.50);
    glEnd();

    // Right blding 3

    glBegin(GL_QUADS);
    glColor3ub(133, 173, 173);
    glVertex2f(0.37, -0.50);
    glVertex2f(0.37, 0.1);
    glVertex2f(0.25, 0.1);
    glVertex2f(0.25, -0.50);
    glEnd();

    // GLASS
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.365, -0.50);
    glVertex2f(0.365, 0.085);
    glVertex2f(0.30, 0.085);
    glVertex2f(0.30, -0.50);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.29, -0.50);
    glVertex2f(0.29, 0.085);
    glVertex2f(0.255, 0.085);
    glVertex2f(0.255, -0.50);
    glEnd();

    // Right blding 5

    glBegin(GL_QUADS);
    glColor3ub(117, 163, 163);
    glVertex2f(0.53, -0.50);
    glVertex2f(0.53, 0.3);
    glVertex2f(0.37, 0.3);
    glVertex2f(0.37, -0.50);
    glEnd();

    // glass
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.29);
    glVertex2f(0.525, 0.28);
    glVertex2f(0.42, 0.28);
    glVertex2f(0.42, 0.29);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.27);
    glVertex2f(0.525, 0.26);
    glVertex2f(0.42, 0.26);
    glVertex2f(0.42, 0.27);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.25);
    glVertex2f(0.525, 0.24);
    glVertex2f(0.42, 0.24);
    glVertex2f(0.42, 0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.23);
    glVertex2f(0.525, 0.22);
    glVertex2f(0.42, 0.22);
    glVertex2f(0.42, 0.23);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.21);
    glVertex2f(0.525, 0.20);
    glVertex2f(0.42, 0.20);
    glVertex2f(0.42, 0.21);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.19);
    glVertex2f(0.525, 0.18);
    glVertex2f(0.42, 0.18);
    glVertex2f(0.42, 0.19);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.17);
    glVertex2f(0.525, 0.16);
    glVertex2f(0.42, 0.16);
    glVertex2f(0.42, 0.17);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.15);
    glVertex2f(0.525, 0.14);
    glVertex2f(0.42, 0.14);
    glVertex2f(0.42, 0.15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.13);
    glVertex2f(0.525, 0.12);
    glVertex2f(0.42, 0.12);
    glVertex2f(0.42, 0.13);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.11);
    glVertex2f(0.525, 0.10);
    glVertex2f(0.42, 0.10);
    glVertex2f(0.42, 0.11);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.09);
    glVertex2f(0.525, 0.08);
    glVertex2f(0.42, 0.08);
    glVertex2f(0.42, 0.09);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.07);
    glVertex2f(0.525, 0.06);
    glVertex2f(0.42, 0.06);
    glVertex2f(0.42, 0.07);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.05);
    glVertex2f(0.525, 0.04);
    glVertex2f(0.42, 0.04);
    glVertex2f(0.42, 0.05);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.03);
    glVertex2f(0.525, 0.02);
    glVertex2f(0.42, 0.02);
    glVertex2f(0.42, 0.03);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, 0.01);
    glVertex2f(0.525, 0.00);
    glVertex2f(0.42, 0.00);
    glVertex2f(0.42, 0.01);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.01);
    glVertex2f(0.525, -0.02);
    glVertex2f(0.42, -0.02);
    glVertex2f(0.42, -0.01);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.03);
    glVertex2f(0.525, -0.04);
    glVertex2f(0.42, -0.04);
    glVertex2f(0.42, -0.03);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.05);
    glVertex2f(0.525, -0.06);
    glVertex2f(0.42, -0.06);
    glVertex2f(0.42, -0.05);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.07);
    glVertex2f(0.525, -0.08);
    glVertex2f(0.42, -0.08);
    glVertex2f(0.42, -0.07);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.09);
    glVertex2f(0.525, -0.10);
    glVertex2f(0.42, -0.10);
    glVertex2f(0.42, -0.09);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.11);
    glVertex2f(0.525, -0.12);
    glVertex2f(0.42, -0.12);
    glVertex2f(0.42, -0.11);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.13);
    glVertex2f(0.525, -0.14);
    glVertex2f(0.42, -0.14);
    glVertex2f(0.42, -0.13);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.15);
    glVertex2f(0.525, -0.16);
    glVertex2f(0.42, -0.16);
    glVertex2f(0.42, -0.15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.17);
    glVertex2f(0.525, -0.18);
    glVertex2f(0.42, -0.18);
    glVertex2f(0.42, -0.17);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.19);
    glVertex2f(0.525, -0.20);
    glVertex2f(0.42, -0.20);
    glVertex2f(0.42, -0.19);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.21);
    glVertex2f(0.525, -0.22);
    glVertex2f(0.42, -0.22);
    glVertex2f(0.42, -0.21);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.23);
    glVertex2f(0.525, -0.24);
    glVertex2f(0.42, -0.24);
    glVertex2f(0.42, -0.23);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.25);
    glVertex2f(0.525, -0.26);
    glVertex2f(0.42, -0.26);
    glVertex2f(0.42, -0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.27);
    glVertex2f(0.525, -0.28);
    glVertex2f(0.42, -0.28);
    glVertex2f(0.42, -0.27);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.29);
    glVertex2f(0.525, -0.30);
    glVertex2f(0.42, -0.30);
    glVertex2f(0.42, -0.29);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.31);
    glVertex2f(0.525, -0.32);
    glVertex2f(0.42, -0.32);
    glVertex2f(0.42, -0.31);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.33);
    glVertex2f(0.525, -0.34);
    glVertex2f(0.42, -0.34);
    glVertex2f(0.42, -0.33);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.35);
    glVertex2f(0.525, -0.36);
    glVertex2f(0.42, -0.36);
    glVertex2f(0.42, -0.35);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.37);
    glVertex2f(0.525, -0.38);
    glVertex2f(0.42, -0.38);
    glVertex2f(0.42, -0.37);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.39);
    glVertex2f(0.525, -0.40);
    glVertex2f(0.42, -0.40);
    glVertex2f(0.42, -0.39);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.41);
    glVertex2f(0.525, -0.42);
    glVertex2f(0.42, -0.42);
    glVertex2f(0.42, -0.41);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.43);
    glVertex2f(0.525, -0.44);
    glVertex2f(0.42, -0.44);
    glVertex2f(0.42, -0.43);
    glEnd();

    // Right blding 4

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 153);
    glVertex2f(0.5, -0.50);
    glVertex2f(0.5, -0.21);
    glVertex2f(0.3, -0.21);
    glVertex2f(0.3, -0.50);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(117, 163, 163);
    glVertex2f(0.75, -0.50);
    glVertex2f(0.75, -0.21);
    glVertex2f(0.5, -0.21);
    glVertex2f(0.5, -0.50);
    glEnd();

    // glass

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.23);
    glVertex2f(0.74, -0.22);
    glVertex2f(0.51, -0.22);
    glVertex2f(0.51, -0.23);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.25);
    glVertex2f(0.74, -0.24);
    glVertex2f(0.51, -0.24);
    glVertex2f(0.51, -0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.27);
    glVertex2f(0.74, -0.26);
    glVertex2f(0.51, -0.26);
    glVertex2f(0.51, -0.27);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.29);
    glVertex2f(0.74, -0.28);
    glVertex2f(0.51, -0.28);
    glVertex2f(0.51, -0.29);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.31);
    glVertex2f(0.74, -0.30);
    glVertex2f(0.51, -0.30);
    glVertex2f(0.51, -0.31);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.33);
    glVertex2f(0.74, -0.32);
    glVertex2f(0.51, -0.32);
    glVertex2f(0.51, -0.33);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.35);
    glVertex2f(0.74, -0.34);
    glVertex2f(0.51, -0.34);
    glVertex2f(0.51, -0.35);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.37);
    glVertex2f(0.74, -0.36);
    glVertex2f(0.51, -0.36);
    glVertex2f(0.51, -0.37);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.39);
    glVertex2f(0.74, -0.38);
    glVertex2f(0.51, -0.38);
    glVertex2f(0.51, -0.39);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.41);
    glVertex2f(0.74, -0.40);
    glVertex2f(0.51, -0.40);
    glVertex2f(0.51, -0.41);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.43);
    glVertex2f(0.74, -0.42);
    glVertex2f(0.51, -0.42);
    glVertex2f(0.51, -0.43);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.45);
    glVertex2f(0.74, -0.44);
    glVertex2f(0.51, -0.44);
    glVertex2f(0.51, -0.45);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.74, -0.47);
    glVertex2f(0.74, -0.46);
    glVertex2f(0.51, -0.46);
    glVertex2f(0.51, -0.47);
    glEnd();

    // Right blding 8
    glBegin(GL_QUADS);
    glColor3ub(133, 173, 173);
    glVertex2f(0.85, -0.50);
    glVertex2f(0.85, -0.25);
    glVertex2f(0.8, -0.25);
    glVertex2f(0.8, -0.50);
    glEnd();
    // Right blding 6
    glBegin(GL_QUADS);
    glColor3ub(102, 153, 153);
    glVertex2f(0.85, -0.50);
    glVertex2f(0.85, -0.27);
    glVertex2f(0.75, -0.27);
    glVertex2f(0.75, -0.50);
    glEnd();
    // glass
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.45);
    glVertex2f(0.84, -0.44);
    glVertex2f(0.76, -0.44);
    glVertex2f(0.76, -0.45);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.43);
    glVertex2f(0.84, -0.42);
    glVertex2f(0.76, -0.42);
    glVertex2f(0.76, -0.43);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.41);
    glVertex2f(0.84, -0.40);
    glVertex2f(0.76, -0.40);
    glVertex2f(0.76, -0.41);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.39);
    glVertex2f(0.84, -0.38);
    glVertex2f(0.76, -0.38);
    glVertex2f(0.76, -0.39);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.37);
    glVertex2f(0.84, -0.36);
    glVertex2f(0.76, -0.36);
    glVertex2f(0.76, -0.37);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.34);
    glVertex2f(0.84, -0.35);
    glVertex2f(0.76, -0.35);
    glVertex2f(0.76, -0.34);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.32);
    glVertex2f(0.84, -0.33);
    glVertex2f(0.76, -0.33);
    glVertex2f(0.76, -0.32);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.30);
    glVertex2f(0.84, -0.31);
    glVertex2f(0.76, -0.31);
    glVertex2f(0.76, -0.30);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.84, -0.28);
    glVertex2f(0.84, -0.29);
    glVertex2f(0.76, -0.29);
    glVertex2f(0.76, -0.28);
    glEnd();

    // Right blding 7

    glBegin(GL_QUADS);
    glColor3ub(92, 138, 138);
    glVertex2f(0.9, -0.50);
    glVertex2f(0.9, -0.105);
    glVertex2f(0.85, -0.1);
    glVertex2f(0.85, -0.50);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 153);
    glVertex2f(1., -0.50);
    glVertex2f(1.0, -0.105);
    glVertex2f(0.9, -0.105);
    glVertex2f(0.9, -0.50);
    glEnd();
    // glass
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.45);
    glVertex2f(.995, -0.44);
    glVertex2f(0.91, -0.44);
    glVertex2f(0.91, -0.45);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.43);
    glVertex2f(.995, -0.42);
    glVertex2f(0.91, -0.42);
    glVertex2f(0.91, -0.43);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.41);
    glVertex2f(.995, -0.40);
    glVertex2f(0.91, -0.40);
    glVertex2f(0.91, -0.41);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.39);
    glVertex2f(.995, -0.38);
    glVertex2f(0.91, -0.38);
    glVertex2f(0.91, -0.39);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.37);
    glVertex2f(.995, -0.36);
    glVertex2f(0.91, -0.36);
    glVertex2f(0.91, -0.37);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.35);
    glVertex2f(.995, -0.34);
    glVertex2f(0.91, -0.34);
    glVertex2f(0.91, -0.35);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.33);
    glVertex2f(.995, -0.32);
    glVertex2f(0.91, -0.32);
    glVertex2f(0.91, -0.33);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.31);
    glVertex2f(.995, -0.30);
    glVertex2f(0.91, -0.30);
    glVertex2f(0.91, -0.31);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.29);
    glVertex2f(.995, -0.28);
    glVertex2f(0.91, -0.28);
    glVertex2f(0.91, -0.29);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.27);
    glVertex2f(.995, -0.26);
    glVertex2f(0.91, -0.26);
    glVertex2f(0.91, -0.27);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.25);
    glVertex2f(.995, -0.24);
    glVertex2f(0.91, -0.24);
    glVertex2f(0.91, -0.25);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.23);
    glVertex2f(.995, -0.22);
    glVertex2f(0.91, -0.22);
    glVertex2f(0.91, -0.23);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.21);
    glVertex2f(.995, -0.20);
    glVertex2f(0.91, -0.20);
    glVertex2f(0.91, -0.21);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.19);
    glVertex2f(.995, -0.18);
    glVertex2f(0.91, -0.18);
    glVertex2f(0.91, -0.19);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.17);
    glVertex2f(.995, -0.16);
    glVertex2f(0.91, -0.16);
    glVertex2f(0.91, -0.17);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.15);
    glVertex2f(.995, -0.14);
    glVertex2f(0.91, -0.14);
    glVertex2f(0.91, -0.15);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(.995, -0.13);
    glVertex2f(.995, -0.12);
    glVertex2f(0.91, -0.12);
    glVertex2f(0.91, -0.13);
    glEnd();

    // LEFT SIDE BLDING 1 

    glBegin(GL_QUADS);
    glColor3ub(204, 51, 0);
    glVertex2f(-.95, -0.4);
    glVertex2f(-.95, 0.17);
    glVertex2f(-1.0, 0.17);
    glVertex2f(-1.0, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(230, 57, 0);
    glVertex2f(-.8, -0.4);
    glVertex2f(-.8, 0.17);
    glVertex2f(-.950, 0.17);
    glVertex2f(-.950, -0.4);
    glEnd();

    // glass
    glBegin(GL_QUADS);
    glColor3ub(255, 128, 0);
    glVertex2f(-.81, -0.4);
    glVertex2f(-.81, 0.15);
    glVertex2f(-.945, 0.15);
    glVertex2f(-.945, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(230, 115, 0);
    glVertex2f(-.96, -0.4);
    glVertex2f(-.96, 0.15);
    glVertex2f(-.995, 0.15);
    glVertex2f(-.995, -0.4);
    glEnd();
}

void display_night(){
    // right blding 1

    glBegin(GL_QUADS);
    glColor3ub(163, 163, 194);
    glVertex2f(0.05, -0.50);
    glVertex2f(0.05, 0.15);
    glVertex2f(-0.05, 0.15);
    glVertex2f(-0.05, -0.50);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(179, 179, 204);
    glVertex2f(0.17, -0.50);
    glVertex2f(0.17, 0.15);
    glVertex2f(0.05, 0.15);
    glVertex2f(0.05, -0.50);
    glEnd();
    // glass
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, 0.12);
    glVertex2f(0.16, 0.13);
    glVertex2f(0.06, 0.13);
    glVertex2f(0.06, 0.12);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, 0.10);
    glVertex2f(0.16, 0.11);
    glVertex2f(0.06, 0.11);
    glVertex2f(0.06, 0.10);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, 0.08);
    glVertex2f(0.16, 0.09);
    glVertex2f(0.06, 0.09);
    glVertex2f(0.06, 0.08);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, 0.06);
    glVertex2f(0.16, 0.07);
    glVertex2f(0.06, 0.07);
    glVertex2f(0.06, 0.06);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, 0.04);
    glVertex2f(0.16, 0.05);
    glVertex2f(0.06, 0.05);
    glVertex2f(0.06, 0.04);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, 0.02);
    glVertex2f(0.16, 0.03);
    glVertex2f(0.06, 0.03);
    glVertex2f(0.06, 0.02);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, 0.0);
    glVertex2f(0.16, 0.01);
    glVertex2f(0.06, 0.01);
    glVertex2f(0.06, 0.0);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.02);
    glVertex2f(0.16, -0.01);
    glVertex2f(0.06, -0.01);
    glVertex2f(0.06, -0.02);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.04);
    glVertex2f(0.16, -0.03);
    glVertex2f(0.06, -0.03);
    glVertex2f(0.06, -0.04);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.06);
    glVertex2f(0.16, -0.05);
    glVertex2f(0.06, -0.05);
    glVertex2f(0.06, -0.06);
    glEnd(); //
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.08);
    glVertex2f(0.16, -0.07);
    glVertex2f(0.06, -0.07);
    glVertex2f(0.06, -0.08);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.10);
    glVertex2f(0.16, -0.09);
    glVertex2f(0.06, -0.09);
    glVertex2f(0.06, -0.10);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.12);
    glVertex2f(0.16, -0.11);
    glVertex2f(0.06, -0.11);
    glVertex2f(0.06, -0.12);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.14);
    glVertex2f(0.16, -0.13);
    glVertex2f(0.06, -0.13);
    glVertex2f(0.06, -0.14);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.16);
    glVertex2f(0.16, -0.15);
    glVertex2f(0.06, -0.15);
    glVertex2f(0.06, -0.16);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.18);
    glVertex2f(0.16, -0.17);
    glVertex2f(0.06, -0.17);
    glVertex2f(0.06, -0.18);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.20);
    glVertex2f(0.16, -0.19);
    glVertex2f(0.06, -0.19);
    glVertex2f(0.06, -0.20);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.22);
    glVertex2f(0.16, -0.21);
    glVertex2f(0.06, -0.21);
    glVertex2f(0.06, -0.22);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.24);
    glVertex2f(0.16, -0.23);
    glVertex2f(0.06, -0.23);
    glVertex2f(0.06, -0.24);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.26);
    glVertex2f(0.16, -0.25);
    glVertex2f(0.06, -0.25);
    glVertex2f(0.06, -0.26);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.28);
    glVertex2f(0.16, -0.27);
    glVertex2f(0.06, -0.27);
    glVertex2f(0.06, -0.28);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.30);
    glVertex2f(0.16, -0.29);
    glVertex2f(0.06, -0.29);
    glVertex2f(0.06, -0.30);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.32);
    glVertex2f(0.16, -0.31);
    glVertex2f(0.06, -0.31);
    glVertex2f(0.06, -0.32);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.34);
    glVertex2f(0.16, -0.33);
    glVertex2f(0.06, -0.33);
    glVertex2f(0.06, -0.34);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.36);
    glVertex2f(0.16, -0.35);
    glVertex2f(0.06, -0.35);
    glVertex2f(0.06, -0.36);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.06);
    glVertex2f(0.16, -0.05);
    glVertex2f(0.06, -0.05);
    glVertex2f(0.06, -0.06);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.16, -0.06);
    glVertex2f(0.16, -0.05);
    glVertex2f(0.06, -0.05);
    glVertex2f(0.06, -0.06);
    glEnd();

    // Right blding 2

    glBegin(GL_QUADS);
    glColor3ub(117, 163, 163);
    glVertex2f(0.25, -0.50);
    glVertex2f(0.25, 0.05);
    glVertex2f(0.17, 0.05);
    glVertex2f(0.17, -0.50);
    glEnd();

    // Right blding 3

    glBegin(GL_QUADS);
    glColor3ub(133, 173, 173);
    glVertex2f(0.37, -0.50);
    glVertex2f(0.37, 0.1);
    glVertex2f(0.25, 0.1);
    glVertex2f(0.25, -0.50);
    glEnd();

    // GLASS
    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.365, -0.50);
    glVertex2f(0.365, 0.085);
    glVertex2f(0.30, 0.085);
    glVertex2f(0.30, -0.50);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.29, -0.50);
    glVertex2f(0.29, 0.085);
    glVertex2f(0.255, 0.085);
    glVertex2f(0.255, -0.50);
    glEnd();

    // Right blding 5

    glBegin(GL_QUADS);
    glColor3ub(117, 163, 163);
    glVertex2f(0.53, -0.50);
    glVertex2f(0.53, 0.3);
    glVertex2f(0.37, 0.3);
    glVertex2f(0.37, -0.50);
    glEnd();

    // glass
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.29);
    glVertex2f(0.525, 0.28);
    glVertex2f(0.42, 0.28);
    glVertex2f(0.42, 0.29);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.27);
    glVertex2f(0.525, 0.26);
    glVertex2f(0.42, 0.26);
    glVertex2f(0.42, 0.27);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.25);
    glVertex2f(0.525, 0.24);
    glVertex2f(0.42, 0.24);
    glVertex2f(0.42, 0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.23);
    glVertex2f(0.525, 0.22);
    glVertex2f(0.42, 0.22);
    glVertex2f(0.42, 0.23);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.21);
    glVertex2f(0.525, 0.20);
    glVertex2f(0.42, 0.20);
    glVertex2f(0.42, 0.21);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.18);
    glVertex2f(0.42, 0.18);
    glVertex2f(0.42, 0.19);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.17);
    glVertex2f(0.525, 0.16);
    glVertex2f(0.42, 0.16);
    glVertex2f(0.42, 0.17);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.15);
    glVertex2f(0.525, 0.14);
    glVertex2f(0.42, 0.14);
    glVertex2f(0.42, 0.15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.13);
    glVertex2f(0.525, 0.12);
    glVertex2f(0.42, 0.12);
    glVertex2f(0.42, 0.13);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.11);
    glVertex2f(0.525, 0.10);
    glVertex2f(0.42, 0.10);
    glVertex2f(0.42, 0.11);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.09);
    glVertex2f(0.525, 0.08);
    glVertex2f(0.42, 0.08);
    glVertex2f(0.42, 0.09);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.07);
    glVertex2f(0.525, 0.06);
    glVertex2f(0.42, 0.06);
    glVertex2f(0.42, 0.07);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.05);
    glVertex2f(0.525, 0.04);
    glVertex2f(0.42, 0.04);
    glVertex2f(0.42, 0.05);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.03);
    glVertex2f(0.525, 0.02);
    glVertex2f(0.42, 0.02);
    glVertex2f(0.42, 0.03);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, 0.01);
    glVertex2f(0.525, 0.00);
    glVertex2f(0.42, 0.00);
    glVertex2f(0.42, 0.01);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.01);
    glVertex2f(0.525, -0.02);
    glVertex2f(0.42, -0.02);
    glVertex2f(0.42, -0.01);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.03);
    glVertex2f(0.525, -0.04);
    glVertex2f(0.42, -0.04);
    glVertex2f(0.42, -0.03);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.05);
    glVertex2f(0.525, -0.06);
    glVertex2f(0.42, -0.06);
    glVertex2f(0.42, -0.05);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.07);
    glVertex2f(0.525, -0.08);
    glVertex2f(0.42, -0.08);
    glVertex2f(0.42, -0.07);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.09);
    glVertex2f(0.525, -0.10);
    glVertex2f(0.42, -0.10);
    glVertex2f(0.42, -0.09);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.11);
    glVertex2f(0.525, -0.12);
    glVertex2f(0.42, -0.12);
    glVertex2f(0.42, -0.11);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.13);
    glVertex2f(0.525, -0.14);
    glVertex2f(0.42, -0.14);
    glVertex2f(0.42, -0.13);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.15);
    glVertex2f(0.525, -0.16);
    glVertex2f(0.42, -0.16);
    glVertex2f(0.42, -0.15);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.17);
    glVertex2f(0.525, -0.18);
    glVertex2f(0.42, -0.18);
    glVertex2f(0.42, -0.17);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.19);
    glVertex2f(0.525, -0.20);
    glVertex2f(0.42, -0.20);
    glVertex2f(0.42, -0.19);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.525, -0.21);
    glVertex2f(0.525, -0.22);
    glVertex2f(0.42, -0.22);
    glVertex2f(0.42, -0.21);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.23);
    glVertex2f(0.525, -0.24);
    glVertex2f(0.42, -0.24);
    glVertex2f(0.42, -0.23);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.25);
    glVertex2f(0.525, -0.26);
    glVertex2f(0.42, -0.26);
    glVertex2f(0.42, -0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.27);
    glVertex2f(0.525, -0.28);
    glVertex2f(0.42, -0.28);
    glVertex2f(0.42, -0.27);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.29);
    glVertex2f(0.525, -0.30);
    glVertex2f(0.42, -0.30);
    glVertex2f(0.42, -0.29);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.31);
    glVertex2f(0.525, -0.32);
    glVertex2f(0.42, -0.32);
    glVertex2f(0.42, -0.31);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.33);
    glVertex2f(0.525, -0.34);
    glVertex2f(0.42, -0.34);
    glVertex2f(0.42, -0.33);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.35);
    glVertex2f(0.525, -0.36);
    glVertex2f(0.42, -0.36);
    glVertex2f(0.42, -0.35);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.37);
    glVertex2f(0.525, -0.38);
    glVertex2f(0.42, -0.38);
    glVertex2f(0.42, -0.37);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.39);
    glVertex2f(0.525, -0.40);
    glVertex2f(0.42, -0.40);
    glVertex2f(0.42, -0.39);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.41);
    glVertex2f(0.525, -0.42);
    glVertex2f(0.42, -0.42);
    glVertex2f(0.42, -0.41);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 255);
    glVertex2f(0.525, -0.43);
    glVertex2f(0.525, -0.44);
    glVertex2f(0.42, -0.44);
    glVertex2f(0.42, -0.43);
    glEnd();

    // Right blding 4

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 153);
    glVertex2f(0.5, -0.50);
    glVertex2f(0.5, -0.21);
    glVertex2f(0.3, -0.21);
    glVertex2f(0.3, -0.50);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(117, 163, 163);
    glVertex2f(0.75, -0.50);
    glVertex2f(0.75, -0.21);
    glVertex2f(0.5, -0.21);
    glVertex2f(0.5, -0.50);
    glEnd();

    // glass

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.23);
    glVertex2f(0.74, -0.22);
    glVertex2f(0.51, -0.22);
    glVertex2f(0.51, -0.23);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.25);
    glVertex2f(0.74, -0.24);
    glVertex2f(0.51, -0.24);
    glVertex2f(0.51, -0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.27);
    glVertex2f(0.74, -0.26);
    glVertex2f(0.51, -0.26);
    glVertex2f(0.51, -0.27);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.29);
    glVertex2f(0.74, -0.28);
    glVertex2f(0.51, -0.28);
    glVertex2f(0.51, -0.29);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.31);
    glVertex2f(0.74, -0.30);
    glVertex2f(0.51, -0.30);
    glVertex2f(0.51, -0.31);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.33);
    glVertex2f(0.74, -0.32);
    glVertex2f(0.51, -0.32);
    glVertex2f(0.51, -0.33);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.35);
    glVertex2f(0.74, -0.34);
    glVertex2f(0.51, -0.34);
    glVertex2f(0.51, -0.35);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.37);
    glVertex2f(0.74, -0.36);
    glVertex2f(0.51, -0.36);
    glVertex2f(0.51, -0.37);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.39);
    glVertex2f(0.74, -0.38);
    glVertex2f(0.51, -0.38);
    glVertex2f(0.51, -0.39);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.41);
    glVertex2f(0.74, -0.40);
    glVertex2f(0.51, -0.40);
    glVertex2f(0.51, -0.41);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.43);
    glVertex2f(0.74, -0.42);
    glVertex2f(0.51, -0.42);
    glVertex2f(0.51, -0.43);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.45);
    glVertex2f(0.74, -0.44);
    glVertex2f(0.51, -0.44);
    glVertex2f(0.51, -0.45);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.74, -0.47);
    glVertex2f(0.74, -0.46);
    glVertex2f(0.51, -0.46);
    glVertex2f(0.51, -0.47);
    glEnd();

    // Right blding 8
    glBegin(GL_QUADS);
    glColor3ub(133, 173, 173);
    glVertex2f(0.85, -0.50);
    glVertex2f(0.85, -0.25);
    glVertex2f(0.8, -0.25);
    glVertex2f(0.8, -0.50);
    glEnd();
    // Right blding 6
    glBegin(GL_QUADS);
    glColor3ub(102, 153, 153);
    glVertex2f(0.85, -0.50);
    glVertex2f(0.85, -0.27);
    glVertex2f(0.75, -0.27);
    glVertex2f(0.75, -0.50);
    glEnd();
    // glass
    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.45);
    glVertex2f(0.84, -0.44);
    glVertex2f(0.76, -0.44);
    glVertex2f(0.76, -0.45);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.43);
    glVertex2f(0.84, -0.42);
    glVertex2f(0.76, -0.42);
    glVertex2f(0.76, -0.43);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.41);
    glVertex2f(0.84, -0.40);
    glVertex2f(0.76, -0.40);
    glVertex2f(0.76, -0.41);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.39);
    glVertex2f(0.84, -0.38);
    glVertex2f(0.76, -0.38);
    glVertex2f(0.76, -0.39);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.37);
    glVertex2f(0.84, -0.36);
    glVertex2f(0.76, -0.36);
    glVertex2f(0.76, -0.37);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.34);
    glVertex2f(0.84, -0.35);
    glVertex2f(0.76, -0.35);
    glVertex2f(0.76, -0.34);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.32);
    glVertex2f(0.84, -0.33);
    glVertex2f(0.76, -0.33);
    glVertex2f(0.76, -0.32);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.30);
    glVertex2f(0.84, -0.31);
    glVertex2f(0.76, -0.31);
    glVertex2f(0.76, -0.30);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(0.84, -0.28);
    glVertex2f(0.84, -0.29);
    glVertex2f(0.76, -0.29);
    glVertex2f(0.76, -0.28);
    glEnd();

    // Right blding 7

    glBegin(GL_QUADS);
    glColor3ub(92, 138, 138);
    glVertex2f(0.9, -0.50);
    glVertex2f(0.9, -0.105);
    glVertex2f(0.85, -0.105);
    glVertex2f(0.85, -0.50);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(102, 153, 153);
    glVertex2f(1., -0.50);
    glVertex2f(1.0, -0.105);
    glVertex2f(0.9, -0.105);
    glVertex2f(0.9, -0.50);
    glEnd();
    // glass
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.45);
    glVertex2f(.995, -0.44);
    glVertex2f(0.91, -0.44);
    glVertex2f(0.91, -0.45);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.43);
    glVertex2f(.995, -0.42);
    glVertex2f(0.91, -0.42);
    glVertex2f(0.91, -0.43);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.41);
    glVertex2f(.995, -0.40);
    glVertex2f(0.91, -0.40);
    glVertex2f(0.91, -0.41);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.39);
    glVertex2f(.995, -0.38);
    glVertex2f(0.91, -0.38);
    glVertex2f(0.91, -0.39);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.37);
    glVertex2f(.995, -0.36);
    glVertex2f(0.91, -0.36);
    glVertex2f(0.91, -0.37);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.35);
    glVertex2f(.995, -0.34);
    glVertex2f(0.91, -0.34);
    glVertex2f(0.91, -0.35);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.33);
    glVertex2f(.995, -0.32);
    glVertex2f(0.91, -0.32);
    glVertex2f(0.91, -0.33);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.31);
    glVertex2f(.995, -0.30);
    glVertex2f(0.91, -0.30);
    glVertex2f(0.91, -0.31);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.29);
    glVertex2f(.995, -0.28);
    glVertex2f(0.91, -0.28);
    glVertex2f(0.91, -0.29);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.27);
    glVertex2f(.995, -0.26);
    glVertex2f(0.91, -0.26);
    glVertex2f(0.91, -0.27);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.25);
    glVertex2f(.995, -0.24);
    glVertex2f(0.91, -0.24);
    glVertex2f(0.91, -0.25);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.23);
    glVertex2f(.995, -0.22);
    glVertex2f(0.91, -0.22);
    glVertex2f(0.91, -0.23);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.21);
    glVertex2f(.995, -0.20);
    glVertex2f(0.91, -0.20);
    glVertex2f(0.91, -0.21);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.19);
    glVertex2f(.995, -0.18);
    glVertex2f(0.91, -0.18);
    glVertex2f(0.91, -0.19);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.17);
    glVertex2f(.995, -0.16);
    glVertex2f(0.91, -0.16);
    glVertex2f(0.91, -0.17);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.15);
    glVertex2f(.995, -0.14);
    glVertex2f(0.91, -0.14);
    glVertex2f(0.91, -0.15);
    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 51);
    glVertex2f(.995, -0.13);
    glVertex2f(.995, -0.12);
    glVertex2f(0.91, -0.12);
    glVertex2f(0.91, -0.13);
    glEnd();

     // LEFT SIDE BLDING 1 

    glBegin(GL_QUADS);
    glColor3ub(204, 51, 0);
    glVertex2f(-.95, -0.4);
    glVertex2f(-.95, 0.17);
    glVertex2f(-1.0, 0.17);
    glVertex2f(-1.0, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(230, 57, 0);
    glVertex2f(-.8, -0.4);
    glVertex2f(-.8, 0.17);
    glVertex2f(-.950, 0.17);
    glVertex2f(-.950, -0.4);
    glEnd();

    // glass
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 179);//255 255 230
    glVertex2f(-.81, -0.4);
    glVertex2f(-.81, 0.15);
    glVertex2f(-.945, 0.15);
    glVertex2f(-.945, -0.4);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 179);
    glVertex2f(-.96, -0.4);
    glVertex2f(-.96, 0.15);
    glVertex2f(-.995, 0.15);
    glVertex2f(-.995, -0.4);
    glEnd();
}