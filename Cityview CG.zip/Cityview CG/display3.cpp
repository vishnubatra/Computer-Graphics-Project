#include "displayFunctions.h"
#include "globals.h"

void display3()
{

    glClearColor(1.0, 1.0, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    // SKY

    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0); // bright sky color
    glVertex2f(1.0, -0.4);
    glVertex2f(1.0, 1.0);
    glVertex2f(-1.0, 1.0);
    glVertex2f(-1.0, -0.4);
    glEnd();
    // plane

    glPushMatrix();
    glTranslatef(position6, 0.0f, 0.0f);

    glBegin(GL_QUADS);
    glColor3ub(0, 0, 153);
    glVertex2f(.6, .6);
    glVertex2f(.65, 0.65);
    glVertex2f(0.40, 0.63);
    glVertex2f(0.30, .6);
    glEnd();

    glPointSize(3.0);
    glBegin(GL_POINTS);
    glColor3ub(255, 255, 255);
    glVertex2f(0.45f, 0.62f);
    glVertex2f(0.5f, 0.62f);
    glVertex2f(0.55f, 0.62f);
    glEnd();
    glPopMatrix();

    // Moon
    glColor3f(1, 1, 1);

    int k;
    x = -.8f;
    y = .8f;
    radius = .07f;
    triangleAmount = 20; // # of triangles used to draw circle

    twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    for (k = 0; k <= triangleAmount; k++)
    {
        glVertex2f(
            x + (radius * cos(k * twicePi / triangleAmount)),
            y + (radius * sin(k * twicePi / triangleAmount)));
    }
    glEnd();

    // star
    glPointSize(2.5);
    glBegin(GL_POINTS);
    glColor3ub(255, 255, 255);
    glVertex2f(0.8f, 0.95f);
    glVertex2f(0.9f, 0.9f);
    glVertex2f(0.95f, 0.7f);
    glVertex2f(0.8f, 0.8f);
    glVertex2f(0.7f, 0.9f);
    glVertex2f(0.6f, 0.8f);
    glVertex2f(0.5f, 0.75f);
    glVertex2f(0.4f, 0.9f);
    glVertex2f(0.3f, 0.7f);
    glVertex2f(0.25f, 0.9f);
    glVertex2f(0.25f, 0.7f);
    glVertex2f(0.1f, 0.9f);
    glVertex2f(0.15f, 0.75f);
    glVertex2f(0.0f, 0.8f);
    glVertex2f(-0.7f, 0.9f);
    glVertex2f(-0.8f, 0.95f);
    glVertex2f(-0.4f, 0.8f);
    glVertex2f(-0.8f, 0.95f);
    glVertex2f(-0.9f, 0.9f);
    glVertex2f(-0.95f, 0.7f);
    glVertex2f(-0.8f, 0.8f);
    glVertex2f(-0.7f, 0.9f);
    glVertex2f(-0.6f, 0.8f);
    glVertex2f(-0.5f, 0.75f);
    glVertex2f(-0.4f, 0.9f);
    glVertex2f(-0.3f, 0.7f);
    glVertex2f(-0.25f, 0.9f);
    glVertex2f(-0.25f, 0.7f);
    glVertex2f(-0.15f, 0.75f);
    glVertex2f(-0.1f, 0.9f);
    glEnd();

    display_night();
    display();
}
