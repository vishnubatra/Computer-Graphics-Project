#ifndef GLOBALS_H
#define GLOBALS_H

// Include necessary headers if needed
#include <OpenGL/gl.h>
#include <GLUT/glut.h>

extern GLfloat position;
extern GLfloat speed;
extern GLfloat position1;
extern GLfloat speed1;
extern GLfloat position2;
extern GLfloat speed2;
extern GLfloat position3;
extern GLfloat speed3;
extern GLfloat position5;
extern GLfloat speed5;
extern GLfloat position4;
extern GLfloat speed4;
extern GLfloat position6;
extern GLfloat speed6;

extern GLfloat x;
extern GLfloat y;
extern GLfloat radius;
extern int triangleAmount;
extern GLfloat twicePi;

#endif // GLOBALS_H
